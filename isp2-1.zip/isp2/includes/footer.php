		</div> <!-- container -->
		</div> <!-- .content-wrapper -->
	</main> <!-- .cd-main-content -->
<script src="component/js/jquery-2.1.4.js"></script>
<script src="component/js/bootstrap.js"></script>
<!-- <script src="component/js/jquery.bootgrid.js"></script>  -->
<script src="component/js/jquery.menu-aim.js"></script>
<script src="component/js/main.js"></script>
<script src="component/js/chart.js"></script>
<!-- <script src="component/js/tether.min.js"></script> -->
</body>
</html>